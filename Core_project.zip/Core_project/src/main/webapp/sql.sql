INSERT INTO USERINFO (ID, PW, NICK, REGION, ID_CARD, IS_APPROVED, JOINED_AT) VALUES ('test', 'test123', 'test12', '서울', 'ID_CARD 1', 'N', sysdate);
select * from userinfo;